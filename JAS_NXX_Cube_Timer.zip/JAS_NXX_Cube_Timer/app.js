(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const STORAGE_KEY = "jasNxxCubeTimer.v1";
  const MOVES = ["R", "L", "U", "D", "F", "B"];
  const MODIFIERS = ["", "'", "2"];
  let state = loadState();
  let phase = "idle"; // idle | holding | running
  let startAt = 0;
  let elapsedBefore = 0;
  let frame = null;
  let holdTimer = null;
  let holdReady = false;
  let toastTimer = null;

  function loadState() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
      return {
        solves: Array.isArray(saved.solves) ? saved.solves.filter(s => Number.isFinite(s.time)) : [],
        settings: { inspection: false, sound: false, precision: 2, theme: "red", ...(saved.settings || {}) }
      };
    } catch { return { solves: [], settings: { inspection: false, sound: false, precision: 2, theme: "red" } }; }
  }
  function saveState() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
    catch { toast("Could not save: device storage may be full."); }
  }
  function format(ms, precision = Number(state.settings.precision)) {
    const total = ms / 1000;
    if (total < 60) return total.toFixed(precision);
    const minutes = Math.floor(total / 60);
    const seconds = (total % 60).toFixed(precision).padStart(precision + 3, "0");
    return `${minutes}:${seconds}`;
  }
  function scramble() {
    const result = [];
    let previousFace = "";
    while (result.length < 20) {
      const face = MOVES[Math.floor(Math.random() * MOVES.length)];
      if (face === previousFace) continue;
      result.push(face + MODIFIERS[Math.floor(Math.random() * MODIFIERS.length)]);
      previousFace = face;
    }
    $("scramble").textContent = result.join(" ");
  }
  function toast(message) {
    const el = $("toast");
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("show"), 2200);
  }
  function setPhase(next) {
    phase = next;
    $("timer-display").className = "timer-display" + (next === "holding" ? " ready" : next === "running" ? " running" : "");
    $("timer-label").textContent = next === "holding" ? "RELEASE TO START" : next === "running" ? "SOLVING…" : "HOLD SPACE TO START";
    $("start-btn").textContent = next === "running" ? "STOP TIMER" : "START TIMER";
    $("timer-help").textContent = next === "running" ? "Press Space or tap STOP to record your solve." : "Hold the button or Space, then release to start. Press again to stop.";
  }
  function renderTime(ms) { $("timer-display").textContent = format(ms); }
  function tick() {
    if (phase !== "running") return;
    renderTime(elapsedBefore + performance.now() - startAt);
    frame = requestAnimationFrame(tick);
  }
  function start() {
    if (phase === "running") return;
    cancelAnimationFrame(frame);
    elapsedBefore = 0;
    startAt = performance.now();
    setPhase("running");
    frame = requestAnimationFrame(tick);
    if (state.settings.sound) beep(660, .045);
  }
  function stop() {
    if (phase !== "running") return;
    const finalTime = Math.max(0, elapsedBefore + performance.now() - startAt);
    cancelAnimationFrame(frame);
    state.solves.unshift({ time: Math.round(finalTime), date: new Date().toISOString(), scramble: $("scramble").textContent });
    state.solves = state.solves.slice(0, 500);
    saveState();
    renderTime(finalTime);
    setPhase("idle");
    renderStats();
    scramble();
    if (state.settings.sound) beep(880, .07);
    toast(`Solve saved: ${format(finalTime)}`);
  }
  function toggleTimer() { phase === "running" ? stop() : start(); }
  function resetTimer() {
    cancelAnimationFrame(frame);
    clearTimeout(holdTimer);
    phase = "idle"; elapsedBefore = 0;
    renderTime(0); setPhase("idle");
  }
  function beep(frequency, duration) {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const oscillator = ctx.createOscillator();
      const gain = ctx.createGain();
      oscillator.frequency.value = frequency;
      gain.gain.value = .035;
      oscillator.connect(gain); gain.connect(ctx.destination);
      oscillator.start(); oscillator.stop(ctx.currentTime + duration);
      oscillator.onended = () => ctx.close();
    } catch { /* Audio is optional. */ }
  }
  function average(values) {
    if (!values.length) return null;
    return values.reduce((a, b) => a + b, 0) / values.length;
  }
  function ao5(solves) {
    if (solves.length < 5) return null;
    const five = solves.slice(0, 5).map(s => s.time).sort((a, b) => a - b);
    return average(five.slice(1, 4));
  }
  function renderStats() {
    const solves = state.solves;
    const best = solves.length ? Math.min(...solves.map(s => s.time)) : null;
    const avg = average(solves.map(s => s.time));
    $("last-time").textContent = solves[0] ? format(solves[0].time) : "—";
    $("best-time").textContent = best !== null ? format(best) : "—";
    $("solve-count").textContent = solves.length;
    $("stats-count").textContent = solves.length;
    $("stats-best").textContent = best !== null ? format(best) : "—";
    $("stats-average").textContent = avg !== null ? format(avg) : "—";
    $("stats-ao5").textContent = ao5(solves) !== null ? format(ao5(solves)) : "—";
    const list = $("solve-list");
    list.replaceChildren();
    if (!solves.length) {
      const li = document.createElement("li");
      li.className = "empty-state"; li.textContent = "Your solves will appear here.";
      list.append(li); return;
    }
    solves.slice(0, 30).forEach((solve, index) => {
      const li = document.createElement("li");
      const left = document.createElement("span");
      left.textContent = `#${String(solves.length - index).padStart(2, "0")}  ${new Date(solve.date).toLocaleDateString()}`;
      const right = document.createElement("strong");
      right.textContent = format(solve.time);
      li.append(left, right); list.append(li);
    });
  }
  function applySettings() {
    document.documentElement.dataset.theme = state.settings.theme;
    $("inspection-setting").checked = !!state.settings.inspection;
    $("sound-setting").checked = !!state.settings.sound;
    $("theme-setting").value = state.settings.theme;
    $("precision-setting").value = String(state.settings.precision);
    if (phase !== "running") renderTime(0);
    renderStats();
  }
  function setSetting(key, value) { state.settings[key] = value; saveState(); applySettings(); }

  // Timer controls: touch and mouse are both supported.
  $("start-btn").addEventListener("click", toggleTimer);
  $("timer-display").addEventListener("click", toggleTimer);
  $("reset-btn").addEventListener("click", resetTimer);
  $("new-scramble").addEventListener("click", () => { if (phase !== "running") { scramble(); toast("New scramble generated."); } });
  $("settings-open").addEventListener("click", () => $("settings-dialog").showModal());
  $("inspection-setting").addEventListener("change", e => setSetting("inspection", e.target.checked));
  $("sound-setting").addEventListener("change", e => setSetting("sound", e.target.checked));
  $("theme-setting").addEventListener("change", e => setSetting("theme", e.target.value));
  $("precision-setting").addEventListener("change", e => setSetting("precision", Number(e.target.value)));
  $("clear-solves").addEventListener("click", () => {
    if (!state.solves.length) return toast("There is no solve history to clear.");
    if (confirm("Delete all saved solves? This cannot be undone.")) { state.solves = []; saveState(); renderStats(); toast("Solve history cleared."); }
  });
  $("export-btn").addEventListener("click", () => {
    if (!state.solves.length) return toast("No solves to export yet.");
    const rows = [["number", "time_ms", "time", "date", "scramble"]];
    state.solves.forEach((s, i) => rows.push([i + 1, s.time, format(s.time), s.date, s.scramble]));
    const csv = rows.map(row => row.map(value => `"${String(value).replace(/"/g, '""')}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    const a = document.createElement("a"); a.href = url; a.download = "jas-nxx-solves.csv"; a.click();
    URL.revokeObjectURL(url);
  });

  document.querySelectorAll("[data-view]").forEach(button => button.addEventListener("click", () => {
    document.querySelectorAll("[data-view]").forEach(b => b.classList.toggle("active", b === button));
    document.querySelectorAll(".view").forEach(v => v.classList.toggle("active", v.id === `${button.dataset.view}-view`));
  }));

  function isTypingTarget(target) { return target && ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName); }
  document.addEventListener("keydown", e => {
    if (isTypingTarget(e.target) || $("settings-dialog").open) return;
    if (e.code === "Space") {
      e.preventDefault();
      if (phase === "running") { stop(); return; }
      if (e.repeat || phase === "holding") return;
      setPhase("holding");
      holdReady = false;
      holdTimer = setTimeout(() => { holdReady = true; $("timer-label").textContent = "READY — RELEASE SPACE"; }, 450);
    }
    if (e.key.toLowerCase() === "r" && phase !== "running") scramble();
  });
  document.addEventListener("keyup", e => {
    if (e.code !== "Space" || isTypingTarget(e.target) || $("settings-dialog").open) return;
    clearTimeout(holdTimer);
    if (phase === "holding") {
      if (holdReady) start();
      else setPhase("idle");
    }
  });
  // Touch-and-hold gesture on the large timer display.
  const display = $("timer-display");
  display.addEventListener("pointerdown", e => {
    if (e.pointerType === "mouse" || phase === "running") return;
    holdReady = false;
    setPhase("holding");
    holdTimer = setTimeout(() => { holdReady = true; $("timer-label").textContent = "READY — RELEASE"; }, 450);
  });
  display.addEventListener("pointerup", e => {
    if (e.pointerType === "mouse" || phase !== "holding") return;
    clearTimeout(holdTimer);
    if (holdReady) start(); else setPhase("idle");
  });
  display.addEventListener("pointercancel", () => { clearTimeout(holdTimer); if (phase === "holding") setPhase("idle"); });

  scramble();
  applySettings();
  setPhase("idle");
  renderTime(0);
})();
