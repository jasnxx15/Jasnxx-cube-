# JAS NXX Cube Timer

A responsive Rubik's Cube timer built with plain HTML, CSS, and JavaScript.

## Features
- Spacebar and on-screen timer controls
- Touch-friendly timer display
- Random 3×3 scramble generator
- Solve history saved in browser local storage
- Best time, average, and Ao5 summary
- CSV export
- Settings for theme, sound, and decimal precision
- Responsive mobile and desktop layout

## Run locally
1. Download and unzip the project.
2. Open `index.html` in a modern browser.

For a local web server (recommended):
- Open the project folder in VS Code and use the Live Server extension, or
- Run `python -m http.server 8000` from this folder, then visit `http://localhost:8000`.

## Use on Android
1. Put the project files on a static hosting service such as GitHub Pages or Netlify.
2. Open the published website in Chrome.
3. Use Chrome's menu and choose **Add to Home screen** or **Install app** if offered.

## Storage and privacy
Solve history and settings are stored in this browser on this device using `localStorage`. Clearing browser site data may erase them. The app does not send solve data to a server.

## Notes
- The scramble generator creates random move sequences for casual practice; it is not a competition-certified scramble implementation.
- Inspection is reserved as a setting toggle in this starter build; the timer currently starts directly.
