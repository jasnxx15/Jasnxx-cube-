JASNXX CUBE TIMER — PWA PACKAGE

Files:
- index.html: your cube timer app with PWA metadata and service-worker registration
- manifest.json: app name, description, display settings, and icon declarations
- service-worker.js: basic offline cache
- icons/: 192px, 512px, and maskable PNG app icons

How to use:
1. Upload the contents of this folder to a website host that serves HTTPS.
2. Make sure index.html, manifest.json, service-worker.js, and the icons folder are at the same site root.
3. Open the HTTPS website URL in Chrome.
4. In PWABuilder, enter that HTTPS URL and run the validation again.

Note:
- PWABuilder needs a live HTTPS URL to test the deployed app; opening index.html directly from phone storage is not enough.
- This package fixes the missing manifest name/description and supplies the required icons.
- The app's solve history is stored locally in the browser on that device.
